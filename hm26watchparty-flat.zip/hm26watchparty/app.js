/* HM26 Watch Party: UI, game layer, menu picker and budget math. Loads after data.js, seed.js and store.js. */
(() => {
'use strict';

/* ---------- constants ---------- */
const TABS = ['board','guests','menu','budget','venue','flyer'];
const PANELS = ['board','guests','menu','budget'];
const DOORS = Date.UTC(2026,10,3,23,0,0);     // 5:00 PM CST, Nov 3
const WRAP_UP = Date.UTC(2026,10,4,6,0,0);    // midnight CST
const SVC = 0.24, TAX = 0.125, MIN_FB = 5000, DEPOSIT = 767.30, BOARDROOM = 500;
const DEFAULT_SETTINGS = {headcount:300, peak:null, cap:0, target:0, barHours:7, bartenders:null, cashiers:0};
const OFF_MSG = 'The shared board, guest list, menu picks and budget load when this page is opened in Claude while signed in. The Venue and Flyer tabs work anywhere.';
const LOCAL_WARN = "This browser isn't saving changes (a private window or blocked storage). Export a backup before you close the tab.";
const RO_MSG = "You're viewing. Checking things off and editing need Contributor or Editor access from Josh.";

const BADGES = [
  {id:'held',    name:'Date Held',         hint:'Hold Nov 3 at the hotel',              test:s=>s.has('hold-date')},
  {id:'signed',  name:'Signed & Sealed',   hint:'Sign the contract and pay the deposit', test:s=>s.has('sign-contract') && s.has('pay-deposit')},
  {id:'paid',    name:'Paid in Full',      hint:'Pay the remaining balance',             test:s=>s.has('pay-balance')},
  {id:'clean',   name:'Clean Disclaimer',  hint:'Fix the flyer disclaimer',              test:s=>s.has('fix-disclaimer')},
  {id:'menu',    name:'Menu Locked',       hint:'Food, bar and both AV orders done',     test:s=>['pick-food','pick-bar','av-screens','av-band'].every(i=>s.has(i))},
  {id:'feast',   name:'Feast Mode',        hint:'Menu picks clear the $5,000 minimum',   test:s=>s.budget.fb >= MIN_FB},
  {id:'count',   name:'Headcount Locked',  hint:'Send the final headcount',              test:s=>s.has('final-count')},
  {id:'books',   name:'Balanced Books',    hint:'Every cost priced and under the ceiling',   test:s=>s.budget.cap>0 && state.expenses.length>0 && s.budget.unpriced===0 && s.budget.all<=s.budget.cap},
  {id:'half',    name:'Halfway Reporting', hint:'Finish half the to-dos',                test:s=>s.total>0 && s.done*2>=s.total},
  {id:'century', name:'Century Club',      hint:'Invite 100 people',                     test:s=>s.invitedNames>=100},
  {id:'full',    name:'Full House',        hint:'150 confirmed guests',                  test:s=>s.confirmed>=150},
  {id:'called',  name:'Race Called',       hint:'Finish every to-do',                    test:s=>s.total>0 && s.done===s.total},
];

/* ---------- state ---------- */
const state = {
  dbStatus:'pending', mode:'pending', readOnly:false, me:null, quietUntil:0,
  tasks:[], guests:[], picks:{}, expenses:[], settings:Object.assign({}, DEFAULT_SETTINGS),
  loaded:{tasks:false, guests:false, picks:false, expenses:false, settings:false},
  tab:'board', view:'deadline', hideDone:false, doneOpen:false,
  statusFilter:'all', editing:null, drafts:{}, confirm:null,
  names:{}, badgeBase:null, pop:null, mSearch:'', mPicked:false,
};
let db = null, user = null;
const pending = new Set();
const mine = new Set();
const dirty = new Set();
let settingsDirty = false, settingsTimer = 0, settingsChain = Promise.resolve();

/* ---------- helpers ---------- */
const $ = (s, r=document) => r.querySelector(s);
const $$ = (s, r=document) => Array.from(r.querySelectorAll(s));
function h(tag, attrs, ...kids){
  const el = document.createElement(tag);
  if (attrs) for (const [k,v] of Object.entries(attrs)){
    if (v == null || v === false) continue;
    if (k === 'class') el.className = v;
    else if (k === 'style') el.style.cssText = v;
    else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2), v);
    else el.setAttribute(k, v === true ? '' : String(v));
  }
  for (const c of kids.flat(Infinity)){
    if (c == null || c === false) continue;
    el.append(c.nodeType ? c : document.createTextNode(String(c)));
  }
  return el;
}
const m0 = new Intl.NumberFormat('en-US',{style:'currency',currency:'USD',maximumFractionDigits:0});
const m2 = new Intl.NumberFormat('en-US',{style:'currency',currency:'USD',minimumFractionDigits:2,maximumFractionDigits:2});
const nf = new Intl.NumberFormat('en-US');
const fmt0 = n => m0.format(Math.round(n));
const fmt2 = n => m2.format(n);
const clamp = (n,a,b) => Math.min(b, Math.max(a, n));
const num = (v,d=0) => { const n = Number(v); return Number.isFinite(n) ? n : d; };
const str = (v,max) => typeof v === 'string' ? v.trim().slice(0,max) : '';
const isISO = v => typeof v === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(v);
const nowISO = () => new Date().toISOString();
const meId = () => (state.me && state.me.id) || null;
const canWrite = () => !!db && state.dbStatus === 'on' && !state.readOnly;
const reduceMotion = () => { try { return matchMedia('(prefers-reduced-motion: reduce)').matches; } catch(e){ return false; } };
const catOf = k => EXP_CATS.find(c => c.key === k) || EXP_CATS[EXP_CATS.length-1];
const plural = (n, one, many) => n === 1 ? one : many;

function todayISO(){
  try { return new Intl.DateTimeFormat('en-CA',{timeZone:'America/Chicago',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date()); }
  catch(e){ return new Date().toISOString().slice(0,10); }
}
function dayNum(iso){ const [y,m,d] = iso.split('-').map(Number); return Date.UTC(y,m-1,d)/864e5; }
const daysFromToday = iso => dayNum(iso) - dayNum(todayISO());
function fmtDate(iso, opts){
  const [y,m,d] = iso.split('-').map(Number);
  return new Date(Date.UTC(y,m-1,d)).toLocaleDateString('en-US', Object.assign({weekday:'short',month:'short',day:'numeric',timeZone:'UTC'}, opts||{}));
}
function fmtStamp(s){
  if (!s) return '';
  if (isISO(s)) return fmtDate(s, {weekday:undefined});
  const d = new Date(s); if (isNaN(d)) return '';
  return d.toLocaleDateString('en-US',{month:'short',day:'numeric',timeZone:'America/Chicago'});
}
function setIfIdle(el, v){ if (el && document.activeElement !== el) el.value = v; }
function withFocus(container, fn){
  const a = document.activeElement;
  const fk = a && container.contains(a) ? a.getAttribute('data-fk') : null;
  fn();
  if (fk){ const n = container.querySelector('[data-fk="'+ (window.CSS && CSS.escape ? CSS.escape(fk) : fk) +'"]'); if (n) n.focus({preventScroll:true}); }
}
function emptyCard(title, text){ return h('div',{class:'empty'}, h('b',null,title), h('span',null,text)); }

/* ---------- prefs (this browser only) ---------- */
const PREF_KEY = 'hm26-watch-prefs';
function loadPrefs(){
  try {
    const p = JSON.parse(localStorage.getItem(PREF_KEY) || '{}');
    if (TABS.includes(p.tab)) state.tab = p.tab;
    if (p.view === 'stream' || p.view === 'deadline') state.view = p.view;
    state.hideDone = !!p.hideDone;
  } catch(e){}
}
function savePrefs(){ try { localStorage.setItem(PREF_KEY, JSON.stringify({tab:state.tab, view:state.view, hideDone:state.hideDone})); } catch(e){} }

/* ---------- toasts + confetti ---------- */
function toast(title, text){
  const box = $('#toasts');
  const t = h('div',{class:'toast'}, h('b',null,title), text ? h('span',null,text) : null);
  box.append(t);
  while (box.children.length > 3) box.firstChild.remove();
  setTimeout(() => t.remove(), 3800);
}
const confetti = (() => {
  let cv = null, ctx = null, parts = [], raf = 0;
  function colors(){
    const cs = getComputedStyle(document.documentElement);
    return ['--brand','--red','--brand-ink','--red-ink','--plate'].map(v => cs.getPropertyValue(v).trim() || '#522A77');
  }
  function ensure(){
    if (cv) return;
    cv = h('canvas',{class:'confetti','aria-hidden':'true'}); document.body.append(cv);
    ctx = cv.getContext('2d'); size(); addEventListener('resize', size);
  }
  function size(){ const d = devicePixelRatio || 1; cv.width = innerWidth*d; cv.height = innerHeight*d; ctx.setTransform(d,0,0,d,0,0); }
  function add(x, y, n, power, down){
    if (reduceMotion()) return;
    ensure(); const cols = colors();
    for (let i = 0; i < n; i++){
      const a = down ? Math.PI/2 + (Math.random()-.5)*1.2 : -Math.PI/2 + (Math.random()-.5)*2.2;
      const sp = (down ? 2 : 4) + Math.random()*6*power;
      parts.push({x, y, vx:Math.cos(a)*sp, vy:Math.sin(a)*sp, w:5+Math.random()*7, h:3+Math.random()*5, r:Math.random()*6.3, vr:(Math.random()-.5)*.35, c:cols[i % cols.length], life:0, max:80+Math.random()*80});
    }
    if (!raf) raf = requestAnimationFrame(tick);
  }
  function tick(){
    ctx.clearRect(0,0,innerWidth,innerHeight);
    parts = parts.filter(p => p.life < p.max && p.y < innerHeight + 30);
    for (const p of parts){
      p.vy += .22; p.vx *= .985; p.x += p.vx; p.y += p.vy; p.r += p.vr; p.life++;
      ctx.save(); ctx.globalAlpha = Math.max(0, 1 - p.life/p.max); ctx.translate(p.x,p.y); ctx.rotate(p.r);
      ctx.fillStyle = p.c; ctx.fillRect(-p.w/2,-p.h/2,p.w,p.h); ctx.restore();
    }
    raf = parts.length ? requestAnimationFrame(tick) : 0;
    if (!raf) ctx.clearRect(0,0,innerWidth,innerHeight);
  }
  return {
    burst(x, y, n=40, power=1){ add(x, y, n, power, false); },
    rain(){ for (let i = 0; i < 9; i++) setTimeout(() => add(Math.random()*innerWidth, -10, 45, 1, true), i*140); },
  };
})();

/* ---------- copy ---------- */
async function copyText(text, label, fallbackEl){
  try {
    await navigator.clipboard.writeText(text);
    toast('Copied', label);
  } catch(e){
    if (fallbackEl){ try { const r = document.createRange(); r.selectNodeContents(fallbackEl); const s = getSelection(); s.removeAllRanges(); s.addRange(r); } catch(_){} toast('Select to copy', 'Copying is blocked here. The text is highlighted.'); return; }
    const fb = $('#copyFb'); fb.hidden = false; const ta = $('#copyFbText'); ta.value = text; ta.focus(); ta.select();
    toast('Select to copy', 'Copying is blocked here, so the text is selected below.');
  }
}

/* ---------- cleaning shared data (untrusted) ---------- */
function cleanTask(d){
  const x = d.data() || {};
  return {id:d.id, title:str(x.title,140) || 'Untitled to-do', detail:str(x.detail,500),
    stream:STREAMS.some(s=>s.key===x.stream) ? x.stream : 'night', due:isISO(x.due) ? x.due : null,
    votes:clamp(Math.round(num(x.votes,10)),0,100), done:x.done===true,
    doneBy:typeof x.doneBy==='string' ? x.doneBy : null, doneAt:typeof x.doneAt==='string' ? x.doneAt : null,
    custom:x.custom===true, order:num(x.order,9999)};
}
function cleanGuest(d){
  const x = d.data() || {};
  return {id:d.id, name:str(x.name,80) || 'Unnamed guest', group:GROUPS.some(g=>g.key===x.group) ? x.group : 'friends',
    status:STATUSES.some(s=>s.key===x.status) ? x.status : 'todo', plusOnes:clamp(Math.round(num(x.plusOnes,0)),0,5),
    contact:str(x.contact,120), notes:str(x.notes,200), addedBy:typeof x.addedBy==='string' ? x.addedBy : null};
}
function cleanPick(d){ const x = d.data() || {}; return {id:d.id, qty:Math.max(0, num(x.qty,0)), follow:x.follow===true}; }
function cleanExp(d){
  const x = d.data() || {};
  return {id:d.id, label:str(x.label,80) || 'Untitled cost', cat:EXP_CATS.some(c=>c.key===x.cat) ? x.cat : 'other',
    vendor:str(x.vendor,80), amount:Math.max(0, num(x.amount,0)), status:EXP_STATUS.some(s=>s.key===x.status) ? x.status : 'estimate',
    notes:str(x.notes,200), order:num(x.order,9999)};
}
function cleanSettings(x){
  x = x || {};
  return {headcount:clamp(Math.round(num(x.headcount,300)),1,5000), cap:Math.max(0, num(x.cap,0)), target:Math.max(0, num(x.target,0)),
    peak:x.peak == null || x.peak === '' ? null : clamp(Math.round(num(x.peak,0)),1,5000),
    barHours:clamp(Math.round(num(x.barHours,7)),1,12),
    bartenders:x.bartenders == null || x.bartenders === '' ? null : clamp(Math.round(num(x.bartenders,0)),0,20),
    cashiers:clamp(Math.round(num(x.cashiers,0)),0,10)};
}

/* ---------- budget math ---------- */
function pickQty(item, pick, hc){ return (item.unit === 'pp' && pick.follow) ? hc : pick.qty; }
function lineCost(item, qty){ return item.unit === 'pc50' ? item.price*qty/50 : item.price*qty; }
function defaultQty(item, hc){
  switch (item.unit){
    case 'pp': return hc;
    case 'pc50': return Math.max(50, Math.ceil(hc/50)*50);
    case 'dozen': return Math.max(1, Math.ceil(hc/12));
    case 'drink': return hc;
    case 'gallon': return 2;
    case 'bottle': return 12;
    default: return item.serves ? Math.max(1, Math.ceil(hc/item.serves)) : 50;
  }
}
const staffFee = hours => 150 + 25*Math.max(0, hours-2);
function budget(){
  const S = state.settings, hc = S.headcount, peak = S.peak || hc;
  const lines = []; let food = 0, bar = 0, att = 0, carve = 0, pieces = 0, drinks = 0, hourly = null;
  for (const [id, p] of Object.entries(state.picks)){
    if (id.startsWith('hourly-')){
      const parts = id.split('-'); const t = HOURLY.find(x => x.key === parts[1]); const hrs = Number(parts[2]);
      if (t && hrs >= 1 && hrs <= 4){ const cost = t.prices[hrs-1]*hc; hourly = {tier:t, hours:hrs, price:t.prices[hrs-1], cost}; bar += cost; }
      continue;
    }
    const it = ITEMS[id]; if (!it) continue;
    const q = pickQty(it, p, hc), c = lineCost(it, q);
    lines.push({item:it, qty:q, cost:c});
    if (it.kind === 'bar') bar += c; else food += c;
    if (it.att) att += 100*it.att;
    if (it.carver) carve += 100;
    if (it.unit === 'pc50') pieces += q;
    if (it.unit === 'drink') drinks += q;
  }
  const autoBt = (drinks > 0 && !hourly) ? Math.max(1, Math.ceil(peak/100)) : 0;
  const bartenders = S.bartenders == null ? autoBt : S.bartenders;
  const btFee = bartenders*staffFee(S.barHours), cashFee = S.cashiers*staffFee(S.barHours);
  const fb = food + bar, shortfall = Math.max(0, MIN_FB - fb);
  const hotelExp = state.expenses.filter(e => catOf(e.cat).hotel), hotelExpSum = hotelExp.reduce((a,e)=>a+e.amount,0);
  const outside = state.expenses.filter(e => !catOf(e.cat).hotel), outsideSum = outside.reduce((a,e)=>a+e.amount,0);
  const fees = att + carve + btFee + cashFee;
  const sub = fb + shortfall + fees + BOARDROOM + hotelExpSum;
  const svc = sub*SVC, tax = (sub+svc)*TAX, hotelTotal = sub + svc + tax;
  const all = hotelTotal + outsideSum;
  return {hc, peak, lines, food, bar, fb, shortfall, att, carve, bartenders, autoBt, btFee, cashFee, fees, hotelExp, hotelExpSum,
    outside, outsideSum, sub, svc, tax, hotelTotal, balance:hotelTotal - DEPOSIT, all, perGuest: hc ? all/hc : 0,
    pieces, drinks, hourly, cap:S.cap, target:S.target, unpriced:state.expenses.filter(e => !(e.amount > 0)).length};
}

/* ---------- stats ---------- */
function stats(){
  const T = state.tasks, total = T.length, doneList = T.filter(t => t.done), done = doneList.length;
  const ids = new Set(doneList.map(t => t.id));
  const votesAll = T.reduce((a,t)=>a+t.votes,0), votes = doneList.reduce((a,t)=>a+t.votes,0);
  const pct = total ? (done === total ? 100 : Math.floor(done/total*100)) : 0;
  const streams = STREAMS.map(s => { const ts = T.filter(t => t.stream === s.key); return {key:s.key, total:ts.length, done:ts.filter(t=>t.done).length}; });
  const G = state.guests, ppl = st => G.filter(g => g.status === st).reduce((a,g)=>a+1+g.plusOnes,0);
  return {total, done, pct, votes, votesAll, streams, has:id => ids.has(id),
    confirmed:ppl('yes'), maybe:ppl('maybe'), awaiting:ppl('invited'), declined:ppl('no'), notInvited:ppl('todo'),
    invitedNames:G.filter(g => g.status !== 'todo').length, budget:budget()};
}
const allLoaded = () => Object.values(state.loaded).every(Boolean);

/* ---------- names ---------- */
function nameFor(id){ return (id && state.names[id]) || 'a teammate'; }
async function resolveNames(ids){
  if (!user) return;
  const want = [...new Set(ids.filter(Boolean))]; if (!want.length) return;
  let ps; try { ps = await user.profiles(want); } catch(e){ return; }
  let changed = false;
  for (const id of want){ const n = (ps[id] && ps[id].name) || ''; if (state.names[id] !== n){ state.names[id] = n; changed = true; } }
  if (!changed) return;
  $$('[data-uid]').forEach(el => { el.textContent = el.getAttribute('data-tpl').replace('{n}', nameFor(el.getAttribute('data-uid'))); });
}

/* ---------- render scheduling ---------- */
let rafQueued = false;
function schedule(){ if (rafQueued) return; rafQueued = true; requestAnimationFrame(flush); }
function flush(){
  rafQueued = false;
  renderSummary();
  for (const p of PANELS){
    if (!dirty.has(p) || state.tab !== p) continue;
    if (p === 'guests' && document.activeElement && document.activeElement.closest && document.activeElement.closest('#guestList .g-edit')) continue;
    dirty.delete(p); RENDER[p]();
  }
}
function changed(...names){ names.forEach(n => dirty.add(n)); dirty.add('board'); checkBadges(); schedule(); }
function renderAll(){ PANELS.forEach(p => dirty.add(p)); syncControls(); renderMe(); schedule(); }

/* ---------- budget status ---------- */
const HOTEL_K = (1+SVC)*(1+TAX);
function budgetStatus(B, short){
  const T = B.target, C = B.cap, a = B.all;
  if (C > 0 && a > C) return `${fmt0(a-C)} over the ${short ? '' : fmt0(C) + ' '}ceiling`;
  if (T > 0 && a > T) return C > 0 ? (short ? `${fmt0(a-T)} over target · ${fmt0(C-a)} to ceiling` : `${fmt0(a-T)} over the ${fmt0(T)} target · ${fmt0(C-a)} under the ${fmt0(C)} ceiling`) : `${fmt0(a-T)} over the ${short ? '' : fmt0(T) + ' '}target`;
  if (T > 0) return `${fmt0(T-a)} under the ${short ? '' : fmt0(T) + ' '}target`;
  if (C > 0) return `${fmt0(C-a)} under the ${short ? '' : fmt0(C) + ' '}ceiling`;
  return '';
}
function budgetLevel(B){ return B.cap > 0 && B.all > B.cap ? 'over' : B.target > 0 && B.all > B.target ? 'warn' : 'under'; }
function roomText(B){
  const T = B.target, C = B.cap, a = B.all, parts = [];
  if (C > 0 && a > C) return `To get back under the ceiling, cut about ${fmt0((a-C)/HOTEL_K)} of hotel spending (before service and tax). Every $1,000 at the hotel costs $1,395 after service and tax.`;
  if (T > 0 && a < T) parts.push(`${fmt0((T-a)/HOTEL_K)} to the target`);
  if (C > 0 && a < C) parts.push(`${fmt0((C-a)/HOTEL_K)} to the ceiling`);
  if (!parts.length) return '';
  return `Room left in hotel spending, before service and tax: ${parts.join(', ')}. Every $1,000 at the hotel costs $1,395 after service and tax; outside costs count dollar for dollar.`;
}

/* ---------- summary: ticker, hero bars, tiles ---------- */
function renderSummary(){
  const st = stats(), on = state.dbStatus === 'on' && state.loaded.tasks;
  $('#tkPct').textContent = on ? st.pct + '%' : '--%';
  $('#tkVotes').textContent = on ? nf.format(st.votes) : '--';
  $('#tPct').textContent = on ? st.pct + '%' : '--';
  $('#tPctSub').textContent = on ? `${st.done} of ${st.total} to-dos in` : (state.dbStatus === 'off' ? 'Opens in Claude' : 'Loading the board');
  $('#tPctBar').style.width = (on ? st.pct : 0) + '%';
  $('#tVotes').textContent = on ? nf.format(st.votes) : '--';
  $('#tVotesSub').textContent = on ? `of ${nf.format(st.votesAll)} up for grabs` : 'Every to-do is worth votes';
  const gOn = state.dbStatus === 'on' && state.loaded.guests;
  $('#tGuests').textContent = gOn ? nf.format(st.confirmed) : '--';
  $('#tGuestsSub').textContent = gOn ? `${nf.format(st.maybe)} maybe · 300 expected` : 'Includes +1s';
  $('#tGuestsBar').style.width = gOn ? Math.min(100, st.confirmed/300*100) + '%' : '0%';
  const bOn = state.dbStatus === 'on' && state.loaded.picks && state.loaded.expenses && state.loaded.settings, B = st.budget;
  $('#tBudget').textContent = bOn ? fmt0(B.all) : '--';
  $('#tBudgetSub').textContent = !bOn ? 'Hotel plus outside costs'
    : (B.cap > 0 || B.target > 0) ? budgetStatus(B, true)
    : `${fmt0(B.perGuest)} per guest · no budget set`;
  STREAMS.forEach(s => {
    const ss = st.streams.find(x => x.key === s.key), p = on && ss.total ? ss.done/ss.total*100 : 0;
    const bar = $('#bar-' + s.key); bar.querySelector('.fill').style.width = p + '%';
    const txt = on ? `${s.short} ${ss.done}/${ss.total}` : s.short;
    bar.querySelectorAll('.lbl').forEach(l => { l.textContent = txt; });
    bar.setAttribute('role','img'); bar.setAttribute('aria-label', on ? `${s.label}: ${ss.done} of ${ss.total} done` : s.label);
  });
  $('#called').hidden = !(on && st.total > 0 && st.done === st.total);
}

function tickCountdown(){
  const now = Date.now(); let lab, val;
  if (now < DOORS){
    const m = Math.floor((DOORS - now)/60000), d = Math.floor(m/1440), hh = Math.floor((m % 1440)/60), mm = m % 60;
    lab = 'Doors in'; val = d > 0 ? `${d}d ${String(hh).padStart(2,'0')}h ${String(mm).padStart(2,'0')}m` : `${hh}h ${String(mm).padStart(2,'0')}m`;
  } else if (now < WRAP_UP){ lab = 'Doors are'; val = 'open'; }
  else { lab = "That's a"; val = 'wrap'; }
  $('#tkCountLab').textContent = lab; $('#tkCount').textContent = val;
}

function renderSteps(){
  let nextFound = false;
  $('#steps').replaceChildren(...DEADLINES.map(d => {
    const n = daysFromToday(d.date), past = n < 0; let cls = 'step';
    if (past) cls += ' past'; else if (!nextFound){ cls += ' next'; nextFound = true; }
    return h('li',{class:cls}, h('span',{class:'d'}, fmtDate(d.date)), h('span',{class:'l'}, d.label), h('span',{class:'s'}, d.sub),
      h('span',{class:'r'}, past ? 'Passed' : n === 0 ? 'Today' : n === 1 ? 'Tomorrow' : `In ${n} days`));
  }));
}

function renderMe(){
  const el = $('#me');
  if (!state.me || state.dbStatus !== 'on'){ el.hidden = true; return; }
  el.hidden = false;
  el.replaceChildren(h('img',{src:state.me.avatarUrl, alt:''}), h('span',null, h('b',null, state.me.name || 'You'), ' · ', state.readOnly ? 'view only' : 'can edit'));
}

function noteFor(id){
  const n = $(id);
  if (state.dbStatus === 'off'){ n.hidden = false; n.textContent = OFF_MSG; }
  else if (state.readOnly){ n.hidden = false; n.textContent = RO_MSG; }
  else if (state.mode === 'local' && !LocalStore.persistent){ n.hidden = false; n.textContent = LOCAL_WARN; }
  else n.hidden = true;
}
function syncControls(){
  const ro = !canWrite();
  ['#taskSet','#guestSet','#exSet'].forEach(s => { $(s).disabled = ro; });
  ['#addTaskBtn','#pasteBtn','#hcMenu','#hcBudget','#peakMenu','#peakBudget','#capInput','#targetInput','#useGuests'].forEach(s => { $(s).disabled = ro; });
}

/* ---------- race board ---------- */
function checkBadges(){
  if (!allLoaded()) return;
  const st = stats(), now = new Set(BADGES.filter(b => b.test(st)).map(b => b.id));
  if (state.badgeBase === null || Date.now() < state.quietUntil){ state.badgeBase = now; return; }
  const fresh = [...now].filter(id => !state.badgeBase.has(id));
  state.badgeBase = now;
  if (!fresh.length) return;
  state.pop = new Set(fresh);
  toast(fresh.length > 1 ? 'Badges earned' : 'Badge earned', fresh.map(id => BADGES.find(b => b.id === id).name).join(' · '));
  if (fresh.includes('called')) confetti.rain(); else confetti.burst(innerWidth/2, innerHeight*.3, 90, 1.4);
}
function renderStickers(st){
  const ready = state.dbStatus === 'on' && allLoaded();
  $('#stickers').replaceChildren(...BADGES.map(b => {
    const on = ready && b.test(st);
    const pop = on && state.pop && state.pop.has(b.id);
    return h('div',{class:'sticker ' + (on ? 'on' : 'off') + (pop ? ' pop' : ''), role:'img', 'aria-label': `${b.name}: ${on ? 'earned' : 'locked. ' + b.hint}`},
      h('span',{class:'st-top'}, 'HM26'), h('span',{class:'st-name'}, b.name), h('span',{class:'st-hint'}, on ? '★ Earned' : b.hint));
  }));
  state.pop = null;
}
function dueText(due){
  const n = daysFromToday(due);
  if (n < 0) return `Overdue · ${fmtDate(due)}`;
  if (n === 0) return 'Due today';
  if (n === 1) return 'Due tomorrow';
  return `Due ${fmtDate(due)}`;
}
function taskItem(t, showStream){
  const n = t.due ? daysFromToday(t.due) : null, ro = !canWrite();
  const overdue = !t.done && n !== null && n < 0, soon = !t.done && n !== null && n >= 0 && n <= 2;
  const s = STREAMS.find(x => x.key === t.stream);
  const meta = [];
  if (t.done){
    const when = fmtStamp(t.doneAt);
    if (t.doneBy){ const tpl = `Done${when ? ' ' + when : ''} by {n}`; meta.push(h('span',{class:'by','data-uid':t.doneBy,'data-tpl':tpl}, tpl.replace('{n}', nameFor(t.doneBy)))); }
    else meta.push(h('span',{class:'by'}, when ? `Done ${when}` : 'Done'));
  } else if (t.due) meta.push(h('span',{class:'due'}, dueText(t.due)));
  if (showStream && s) meta.push(h('span',{class:'tag'}, s.label));
  if (t.custom && !ro){
    const armed = state.confirm === 'task:' + t.id;
    meta.push(h('button',{type:'button', class:'linkbtn red', 'data-fk':'td-'+t.id, onclick:() => armed ? removeTask(t.id) : arm('task:' + t.id)}, armed ? 'Confirm remove' : 'Remove'));
  }
  return h('li',{class:'task' + (t.done ? ' is-done' : '') + (overdue ? ' is-overdue' : '') + (soon ? ' is-soon' : '')},
    h('button',{type:'button', class:'oval', 'aria-pressed':t.done ? 'true' : 'false', 'aria-label':(t.done ? 'Mark not done: ' : 'Mark done: ') + t.title,
      'data-fk':'ov-'+t.id, disabled:ro, onclick:e => toggleTask(t.id, e.currentTarget)}),
    h('div',null, h('div',{class:'t-title'}, t.title), t.detail ? h('div',{class:'t-detail'}, t.detail) : null, meta.length ? h('div',{class:'t-meta'}, meta) : null),
    h('span',{class:'votes'}, '+' + t.votes));
}
const byDue = (a,b) => (a.due||'9999') < (b.due||'9999') ? -1 : (a.due||'9999') > (b.due||'9999') ? 1 : a.order - b.order;
function buildTasks(){
  if (state.dbStatus === 'off') return [emptyCard('The race board lives in Claude', 'Open this page in Claude while signed in to see and check off the shared to-dos.')];
  if (state.dbStatus === 'pending' || !state.loaded.tasks) return [emptyCard('Loading the race board', 'To-dos, votes and badges appear here in a moment.')];
  if (!state.tasks.length) return [emptyCard('No to-dos yet', 'Use "Add a to-do" to start the board.')];
  const out = [];
  if (state.view === 'deadline'){
    const undone = state.tasks.filter(t => !t.done).sort(byDue);
    const done = state.tasks.filter(t => t.done).sort((a,b) => (b.doneAt||'').localeCompare(a.doneAt||''));
    const groups = new Map();
    undone.forEach(t => { const k = t.due || 'none'; if (!groups.has(k)) groups.set(k, []); groups.get(k).push(t); });
    for (const [k, ts] of groups){
      const n = k === 'none' ? null : daysFromToday(k);
      const when = n === null ? 'No date' : n < 0 ? 'Overdue' : n === 0 ? 'Today' : n === 1 ? 'Tomorrow' : `In ${n} days`;
      out.push(h('h3',{class:'grp' + (n !== null && n < 0 ? ' overdue' : '')}, h('span',{class:'when'}, when), k === 'none' ? null : h('span',null, fmtDate(k)),
        h('span',{class:'gv'}, `${ts.reduce((a,t)=>a+t.votes,0)} votes`)));
      out.push(h('ul',{class:'tl'}, ts.map(t => taskItem(t, true))));
    }
    if (!undone.length) out.push(emptyCard('Every precinct is in', 'Nothing left on the board. See you at the Renaissance.'));
    if (done.length && !state.hideDone){
      out.push(h('details',{class:'done-grp', open:state.doneOpen, ontoggle:e => { state.doneOpen = e.currentTarget.open; }},
        h('summary',null, `Already in · ${done.length} ${plural(done.length,'precinct','precincts')}`),
        h('ul',{class:'tl'}, done.map(t => taskItem(t, true)))));
    }
  } else {
    for (const s of STREAMS){
      const ts = state.tasks.filter(t => t.stream === s.key);
      if (!ts.length) continue;
      const undone = ts.filter(t => !t.done).sort(byDue), done = ts.filter(t => t.done).sort(byDue);
      const list = state.hideDone ? undone : undone.concat(done);
      out.push(h('h3',{class:'grp'}, h('span',{class:'when'}, s.label), h('span',{class:'gv'}, `${done.length} of ${ts.length} in`)));
      out.push(list.length ? h('ul',{class:'tl'}, list.map(t => taskItem(t, false))) : emptyCard('All in', 'Every to-do here is done.'));
    }
  }
  return out;
}
function renderBoard(){
  noteFor('#boardNote');
  $$('.seg button').forEach(b => b.setAttribute('aria-pressed', b.dataset.view === state.view ? 'true' : 'false'));
  $('#hideDone').checked = state.hideDone;
  renderStickers(stats());
  const box = $('#taskList');
  withFocus(box, () => box.replaceChildren(...buildTasks()));
  resolveNames(state.tasks.filter(t => t.done && t.doneBy).map(t => t.doneBy));
}
function arm(key){
  state.confirm = key; changed('guests','budget');
  setTimeout(() => { if (state.confirm === key){ state.confirm = null; changed('guests','budget'); } }, 4000);
}

/* ---------- guests ---------- */
function renderGuests(){
  noteFor('#guestNote');
  const st = stats(), on = state.dbStatus === 'on' && state.loaded.guests;
  const nums = [
    ['Coming', st.confirmed, 'var(--good)'], ['Maybe', st.maybe, 'var(--warn)'], ['Awaiting reply', st.awaiting, 'var(--brand-soft-strong)'],
    ['Not invited', st.notInvited, null], ["Can't come", st.declined, null]];
  $('#hcNums').replaceChildren(...nums.map(([l,v,c]) => h('div',{class:'hn'}, h('b',null, on ? nf.format(v) : '--'), h('span',null, c ? h('i',{class:'sw', style:'background:' + c}) : null, l))));
  const total = st.confirmed + st.maybe + st.awaiting, max = Math.max(320, total*1.06);
  const pct = v => (v/max*100).toFixed(2) + '%';
  $('#meter').replaceChildren(
    h('div',{class:'s seg-yes', style:'width:' + pct(on ? st.confirmed : 0)}),
    h('div',{class:'s seg-maybe', style:'width:' + pct(on ? st.maybe : 0)}),
    h('div',{class:'s seg-invited', style:'width:' + pct(on ? st.awaiting : 0)}),
    h('div',{class:'mark', style:'left:' + pct(150)}, h('span',null,'150 · Salon 1 set')),
    h('div',{class:'mark end', style:'left:' + pct(300)}, h('span',null,'300 total expected')));
  const counts = {all:state.guests.length}; STATUSES.forEach(s => { counts[s.key] = state.guests.filter(g => g.status === s.key).length; });
  $('#gStatusF').replaceChildren(...[{key:'all', label:'All'}].concat(STATUSES).map(s => h('button',{type:'button', class:'chip', 'aria-pressed':state.statusFilter === s.key ? 'true' : 'false',
    onclick:() => { state.statusFilter = s.key; dirty.add('guests'); schedule(); }}, `${s.label} ${on ? counts[s.key] : ''}`.trim())));
  const box = $('#guestList');
  withFocus(box, () => box.replaceChildren(...buildGuests()));
}
function buildGuests(){
  if (state.dbStatus === 'off') return [emptyCard('The guest list lives in Claude', 'Open this page in Claude while signed in to see and edit the shared list.')];
  if (state.dbStatus === 'pending' || !state.loaded.guests) return [emptyCard('Loading the guest list', 'Names appear here in a moment.')];
  if (!state.guests.length) return [emptyCard('No guests yet', 'Add a name above or paste a whole list.')];
  const q = $('#gSearch').value.trim().toLowerCase(), gf = $('#gGroupF').value;
  const list = state.guests.filter(g => (state.statusFilter === 'all' || g.status === state.statusFilter) && (!gf || g.group === gf) &&
    (!q || (g.name + ' ' + g.notes + ' ' + g.contact).toLowerCase().includes(q)));
  if (!list.length) return [emptyCard('No one matches', 'Try another search or filter.')];
  const out = [];
  for (const grp of GROUPS){
    const gs = list.filter(g => g.group === grp.key).sort((a,b) => a.name.localeCompare(b.name));
    if (!gs.length) continue;
    const ppl = gs.reduce((a,g)=>a+1+g.plusOnes,0);
    out.push(h('h3',{class:'grp'}, h('span',{class:'when'}, grp.label), h('span',{class:'gv'}, `${gs.length} ${plural(gs.length,'name','names')}` + (ppl !== gs.length ? ` · ${ppl} people with +1s` : ''))));
    out.push(h('ul',{class:'gl'}, gs.map(guestRow)));
  }
  return out;
}
function guestRow(g){
  if (state.editing === g.id) return editRow(g);
  const ro = !canWrite();
  const sub = [g.contact, g.notes].filter(Boolean).join(' · ');
  return h('li',{class:'guest'},
    h('div',{class:'g-main'}, h('div',{class:'g-name'}, g.name), sub ? h('div',{class:'g-sub'}, sub) : null),
    h('select',{class:'pill st-' + g.status, 'aria-label':'RSVP for ' + g.name, 'data-fk':'gs-'+g.id, disabled:ro, onchange:e => updateGuest(g.id, {status:e.target.value})},
      STATUSES.map(s => h('option',{value:s.key, selected:s.key === g.status}, s.label))),
    h('div',{class:'plus', role:'group', 'aria-label':'+1s for ' + g.name},
      h('button',{type:'button', 'aria-label':'Fewer +1s', 'data-fk':'gm-'+g.id, disabled:ro || g.plusOnes <= 0, onclick:() => updateGuest(g.id, {plusOnes:g.plusOnes-1})}, '−'),
      h('span',null, '+' + g.plusOnes),
      h('button',{type:'button', 'aria-label':'More +1s', 'data-fk':'gp-'+g.id, disabled:ro || g.plusOnes >= 5, onclick:() => updateGuest(g.id, {plusOnes:g.plusOnes+1})}, '+')),
    h('button',{type:'button', class:'linkbtn edit', 'data-fk':'ge-'+g.id, disabled:ro, onclick:() => { state.editing = g.id; dirty.add('guests'); schedule(); }}, 'Edit'));
}
function editRow(g){
  const d = state.drafts[g.id] || (state.drafts[g.id] = {name:g.name, group:g.group, contact:g.contact, notes:g.notes});
  const upd = k => e => { d[k] = e.target.value; };
  const armed = state.confirm === 'guest:' + g.id;
  return h('li',{class:'guest g-edit'},
    h('div',{class:'g-edit-grid'},
      h('label',{class:'field'}, 'Name', h('input',{value:d.name, maxlength:80, 'data-fk':'en-'+g.id, oninput:upd('name')})),
      h('label',{class:'field'}, 'Group', h('select',{'data-fk':'eg-'+g.id, onchange:upd('group')}, GROUPS.map(x => h('option',{value:x.key, selected:x.key === d.group}, x.label)))),
      h('label',{class:'field'}, 'Email or phone', h('input',{value:d.contact, maxlength:120, 'data-fk':'ec-'+g.id, oninput:upd('contact')})),
      h('label',{class:'field'}, 'Notes', h('input',{value:d.notes, maxlength:200, 'data-fk':'eo-'+g.id, oninput:upd('notes')}))),
    h('div',{class:'g-edit-actions'},
      h('button',{type:'button', class:'btn primary sm', 'data-fk':'es-'+g.id, onclick:() => saveGuest(g.id)}, 'Save'),
      h('button',{type:'button', class:'btn ghost sm', onclick:() => { delete state.drafts[g.id]; state.editing = null; dirty.add('guests'); schedule(); }}, 'Cancel'),
      h('button',{type:'button', class:'btn danger sm', 'data-fk':'er-'+g.id, onclick:() => armed ? removeGuest(g.id) : arm('guest:' + g.id)}, armed ? 'Confirm remove' : 'Remove')));
}
function matchGroup(t){
  t = (t || '').toLowerCase().trim(); if (!t) return null;
  const g = GROUPS.find(x => x.key === t) || GROUPS.find(x => x.label.toLowerCase().includes(t)) || GROUPS.find(x => t.includes(x.key));
  return g ? g.key : null;
}
function headcountText(){
  const st = stats();
  return `Hillar Moore Election Night Event (ref M-WQ83ATW), Tue Nov 3. Headcount as of ${fmtDate(todayISO())}: ${st.confirmed} confirmed, ${st.maybe} maybe, ${st.awaiting} awaiting reply. Counts include +1s.`;
}
function guestListText(){
  const rows = [['Name','Group','Status','+1s','Email or phone','Notes'].join('\t')];
  GROUPS.forEach(grp => state.guests.filter(g => g.group === grp.key).sort((a,b)=>a.name.localeCompare(b.name)).forEach(g => {
    rows.push([g.name, grp.label, STATUSES.find(s=>s.key===g.status).label, g.plusOnes, g.contact, g.notes].map(v => String(v).replace(/\t|\n/g,' ')).join('\t'));
  }));
  return rows.join('\n');
}

/* ---------- menu ---------- */
function priceLabel(it){
  const p = '$' + nf.format(it.price);
  switch (it.unit){
    case 'pp': return p + ' / guest';
    case 'pc50': return p + ' / 50 pcs';
    case 'dozen': return p + ' / dozen';
    case 'gallon': return p + ' / gallon';
    case 'drink': return p + ' / drink';
    case 'bottle': return p + ' / bottle';
    default: return it.per ? `${p} ${it.per}` : it.serves ? `${p} · serves ${it.serves}` : p + ' each';
  }
}
function qtyUnit(it, q){
  switch (it.unit){
    case 'pp': return plural(q,'guest','guests');
    case 'pc50': return 'pieces';
    case 'dozen': return 'dozen';
    case 'gallon': return plural(q,'gallon','gallons');
    case 'drink': return plural(q,'drink','drinks');
    case 'bottle': return plural(q,'bottle','bottles');
    default: return it.carver ? plural(q,'roast','roasts') : it.serves ? plural(q,'order','orders') : 'each';
  }
}
function menuItem(it, hc){
  const p = state.picks[it.id], on = !!p, ro = !canWrite();
  const q = on ? pickQty(it, p, hc) : 0;
  const flags = [];
  if (it.att) flags.push(h('span',{class:'flag'}, it.att > 1 ? `${it.att} attendants +$${100*it.att}` : 'Attendant +$100'));
  if (it.carver) flags.push(h('span',{class:'flag'}, 'Carver +$100'));
  if (it.serves && !it.per) flags.push(h('span',{class:'flag'}, `Serves ${it.serves}`));
  if (it.max) flags.push(h('span',{class:'flag' + ((on ? q : hc) > it.max ? ' warn' : '')}, `Max ${it.max} guests`));
  let qty = null;
  if (on){
    qty = h('div',{class:'mi-qty'},
      h('label',{class:'sr', for:'q-'+it.id}, 'Quantity for ' + it.name),
      h('input',{id:'q-'+it.id, type:'number', min:it.unit === 'pc50' ? 50 : 1, step:it.unit === 'pc50' ? 50 : 1, value:q, inputmode:'numeric', 'data-fk':'q-'+it.id, disabled:ro,
        onchange:e => setPickQty(it.id, e.target.value)}),
      h('span',null, qtyUnit(it, q)),
      h('span',{class:'mi-cost'}, '= ' + fmt0(lineCost(it, q))),
      it.unit === 'pp' ? (p.follow ? h('span',null,'follows guest count') : h('button',{type:'button', class:'linkbtn', disabled:ro, onclick:() => followPick(it.id)}, `Match guest count (${nf.format(hc)})`)) : null);
  }
  return h('div',{class:'mi' + (on ? ' on' : '')},
    h('button',{type:'button', class:'pick', 'aria-pressed':on ? 'true' : 'false', 'aria-label':(on ? 'Remove ' : 'Add ') + it.name, 'data-fk':'pk-'+it.id, disabled:ro, onclick:() => togglePick(it.id)}, on ? 'Added' : 'Add'),
    h('div',{style:'min-width:0'}, h('div',{class:'mi-name'}, it.name), it.desc ? h('div',{class:'mi-desc'}, it.desc) : null, flags.length ? h('div',{class:'mi-flags'}, flags) : null),
    h('div',{class:'mi-price'}, priceLabel(it)),
    qty);
}
function hourlyBlock(B, hc){
  const ro = !canWrite(), S = state.settings;
  const picked = Object.keys(state.picks).find(k => k.startsWith('hourly-'));
  const table = h('div',{class:'hourly'}, h('table',{class:'hg'},
    h('thead',null, h('tr',null, h('th',{scope:'col'}, h('span',{class:'sr'},'Package')), [1,2,3,4].map(n => h('th',{scope:'col'}, `${n} ${plural(n,'hour','hours')}`)))),
    h('tbody',null, HOURLY.map(t => h('tr',null, h('th',{scope:'row'}, t.label), t.prices.map((pr, i) => {
      const id = `hourly-${t.key}-${i+1}`;
      return h('td',null, h('button',{type:'button', 'aria-pressed':picked === id ? 'true' : 'false', 'aria-label':`${t.label} bar, ${i+1} ${plural(i+1,'hour','hours')}, $${pr} per guest`,
        'data-fk':'hb-'+id, disabled:ro, onclick:() => pickHourly(id)}, '$' + pr));
    }))))));
  const info = [];
  if (B.hourly){
    info.push(h('p',{class:'mi-qty', style:'margin:10px 0 0'}, h('span',null, `${B.hourly.tier.label}, ${B.hourly.hours} ${plural(B.hourly.hours,'hour','hours')} × ${nf.format(hc)} guests`), h('span',{class:'mi-cost'}, '= ' + fmt0(B.hourly.cost))));
    if (S.barHours > B.hourly.hours) info.push(h('p',{class:'hint'}, h('span',{class:'flag warn'}, 'Heads up'), ` The bar is set to stay open ${S.barHours} hours, but this package covers ${B.hourly.hours}. Ask Elizabeth to price the extra time.`));
  } else info.push(h('p',{class:'hint'}, 'No hourly package picked. Tap a price to choose one, or use pay-per-drink below.'));
  const btHint = S.bartenders == null ? `Auto (${B.autoBt})` : '';
  const staff = h('div',{class:'staff'},
    h('label',{class:'field'}, 'Bar open (hours)', h('input',{type:'number', min:1, max:12, step:1, value:S.barHours, 'data-fk':'s-hours', disabled:ro, onchange:e => saveSettings({barHours:e.target.value})})),
    h('label',{class:'field'}, 'Bartenders', h('input',{type:'number', min:0, max:20, step:1, value:S.bartenders == null ? '' : S.bartenders, placeholder:btHint, 'data-fk':'s-bt', disabled:ro,
      onchange:e => saveSettings({bartenders:e.target.value === '' ? null : e.target.value})})),
    h('label',{class:'field'}, 'Cashiers (cash bar)', h('input',{type:'number', min:0, max:10, step:1, value:S.cashiers, 'data-fk':'s-cash', disabled:ro, onchange:e => saveSettings({cashiers:e.target.value})})),
    h('p',{class:'hint full', style:'margin:0'}, B.btFee || B.cashFee
      ? `Staff fees: ${fmt0(B.btFee + B.cashFee)} (${B.bartenders} ${plural(B.bartenders,'bartender','bartenders')}${S.cashiers ? `, ${S.cashiers} ${plural(S.cashiers,'cashier','cashiers')}` : ''} at ${fmt0(staffFee(S.barHours))} each for ${S.barHours} hours). Hourly packages include bartenders.`
      : 'Hourly packages include bartenders. Pay-per-drink and cash bars add $150 per bartender or cashier for 2 hours, plus $25 per extra hour. Leave bartenders blank to size it automatically: one per 100 guests at peak.'));
  return [table, info, staff];
}
function renderMenu(){
  noteFor('#menuNote');
  const B = budget(), hc = B.hc, on = state.dbStatus === 'on' && state.loaded.picks;
  setIfIdle($('#hcMenu'), hc); setIfIdle($('#peakMenu'), B.peak);
  $('#feastNum').textContent = on ? fmt0(B.fb) : '--';
  const fm = $('#feastMeter'); fm.firstChild.style.width = (on ? Math.min(100, B.fb/MIN_FB*100) : 0) + '%'; fm.classList.toggle('met', B.fb >= MIN_FB);
  let sub = !on ? 'Before the 24% service charge and 12.5% tax.'
    : B.fb >= MIN_FB ? `Clears the $5,000 minimum by ${fmt0(B.fb - MIN_FB)}. Before 24% service and 12.5% tax.`
    : `${fmt0(MIN_FB - B.fb)} short of the $5,000 minimum. A shortfall is billed as room rental anyway.`;
  if (on && (B.cap > 0 || B.target > 0)) sub += ' ' + (roomText(B).split('. Every')[0] || budgetStatus(B, false)) + '.';
  if (on && B.pieces) sub += ` Hors d'oeuvres: ${nf.format(B.pieces)} pieces, about ${(B.pieces/hc).toFixed(1)} per guest. A common rule of thumb is 6 to 8 per guest when a meal follows, 10 to 15 when it doesn't.`;
  $('#feastSub').textContent = sub;
  const box = $('#menuList');
  if (state.dbStatus === 'off'){ box.replaceChildren(emptyCard('Menu picks live in Claude', 'Open this page in Claude while signed in to pick items. Prices below are for reference.'), ...buildMenu(B, hc, true)); return; }
  withFocus(box, () => box.replaceChildren(...buildMenu(B, hc, false)));
}
function buildMenu(B, hc){
  const q = state.mSearch.trim().toLowerCase(), pickedOnly = state.mPicked, out = [];
  for (const sec of MENU){
    let body = [];
    const sum = sec.special ? (B.hourly ? B.hourly.cost : 0) + B.btFee + B.cashFee
      : B.lines.filter(l => l.item.sec === sec.key).reduce((a,l)=>a+l.cost,0) + (sec.key === 'action' || sec.key === 'sweets' || sec.key === 'carving'
        ? Object.keys(state.picks).map(id => ITEMS[id]).filter(it => it && it.sec === sec.key).reduce((a,it)=>a + (it.att ? 100*it.att : 0) + (it.carver ? 100 : 0), 0) : 0);
    if (sec.special){
      const show = (!q || 'bar hourly package open bar beer wine preferred premium bartender cashier'.includes(q)) && (!pickedOnly || B.hourly || B.btFee || B.cashFee);
      if (!show) continue;
      body = hourlyBlock(B, hc);
    } else {
      const items = sec.items.map(a => ITEMS[a[0]]).filter(it => (!pickedOnly || state.picks[it.id]) && (!q || (it.name + ' ' + it.desc).toLowerCase().includes(q)));
      if (!items.length) continue;
      body = items.map(it => menuItem(it, hc));
    }
    out.push(h('section',{class:'msec', id:'m-' + sec.key},
      h('div',{class:'msec-h'}, h('h3',{class:'sec-h'}, sec.title), sum ? h('span',{class:'msec-sum'}, fmt0(sum) + ' picked') : null),
      h('p',{class:'msec-note'}, sec.note), body));
  }
  if (!out.length) out.push(emptyCard(pickedOnly ? 'Nothing picked yet' : 'No matches', pickedOnly ? 'Turn off "Picked only" and add items.' : 'Try another search.'));
  return out;
}
function orderText(){
  const B = budget(), S = state.settings, out = [`Hillar Moore Election Night Event (ref M-WQ83ATW), Tue Nov 3`, `Draft menu for ${nf.format(B.hc)} guests`, ''];
  for (const sec of MENU){
    if (sec.special){
      if (B.hourly || B.btFee || B.cashFee){
        out.push('Bar');
        if (B.hourly) out.push(`- ${B.hourly.tier.label} hourly bar, ${B.hourly.hours} hours, ${nf.format(B.hc)} guests (${fmt0(B.hourly.cost)})`);
        out.push(`- Bar open ${S.barHours} hours${B.bartenders ? `, ${B.bartenders} ${plural(B.bartenders,'bartender','bartenders')}` : ''}${S.cashiers ? `, ${S.cashiers} ${plural(S.cashiers,'cashier','cashiers')}` : ''}`);
        out.push('');
      }
      continue;
    }
    const ls = B.lines.filter(l => l.item.sec === sec.key); if (!ls.length) continue;
    out.push(sec.title);
    ls.forEach(l => out.push(`- ${l.item.name}: ${nf.format(l.qty)} ${qtyUnit(l.item, l.qty)} (${fmt0(l.cost)})`));
    out.push('');
  }
  out.push(`Estimated food and drink: ${fmt0(B.fb)} before 24% service and 12.5% tax.`);
  return out.join('\n');
}

/* ---------- budget ---------- */
function rl(label, amount, cls){ return h('div',{class:'rl' + (cls ? ' ' + cls : '')}, h('span',{class:'lab'}, label), h('span',{class:'dots','aria-hidden':'true'}), h('span',{class:'amt'}, amount)); }
function renderBudget(){
  noteFor('#budgetNote');
  const B = budget(), S = state.settings, st = stats();
  const on = state.dbStatus === 'on' && state.loaded.picks && state.loaded.expenses && state.loaded.settings;
  $('#bAll').textContent = on ? fmt0(B.all) : '--';
  $('#bPer').textContent = on ? `${fmt0(B.perGuest)} per guest across ${nf.format(B.hc)} (about ${nf.format(B.peak)} at once) · hotel ${fmt0(B.hotelTotal)} + outside ${fmt0(B.outsideSum)}` : '';
  const cb = $('#capBar'), cm = $('#capMsg'), rm = $('#roomMsg');
  if (on && (B.cap > 0 || B.target > 0)){
    const top = B.cap > 0 ? B.cap : B.target, lvl = budgetLevel(B);
    cb.hidden = false; cb.classList.toggle('over', lvl === 'over'); cb.classList.toggle('warn', lvl === 'warn');
    cb.querySelector('i').style.width = Math.min(100, B.all/top*100) + '%';
    const tm = cb.querySelector('.tmark'); tm.hidden = !(B.target > 0 && B.cap > B.target); tm.style.left = (B.target/top*100) + '%';
    cm.className = 'cap-msg ' + lvl; cm.textContent = budgetStatus(B, false); rm.textContent = roomText(B);
  } else { cb.hidden = true; cm.className = 'cap-msg'; cm.textContent = on ? 'Set a target and ceiling to track against them.' : ''; rm.textContent = ''; }
  setIfIdle($('#hcBudget'), B.hc); setIfIdle($('#peakBudget'), B.peak); setIfIdle($('#capInput'), B.cap > 0 ? B.cap : ''); setIfIdle($('#targetInput'), B.target > 0 ? B.target : '');
  const gc = st.confirmed + st.maybe;
  $('#useGuests').textContent = `Use the guest list (${nf.format(gc)} coming or maybe)`;
  const foodN = B.lines.filter(l => l.item.kind === 'food').length;
  const unpricedHotel = B.hotelExp.filter(e => !(e.amount > 0)).length;
  $('#receipt').replaceChildren(...[
    h('div',{class:'rc-head'}, h('b',null,'BANQUET CHECK · ESTIMATE'), h('span',null,'Renaissance Baton Rouge · M-WQ83ATW'), h('span',null,`Tue, Nov 3 · ${nf.format(B.hc)} guests, about ${nf.format(B.peak)} at once`)),
    rl(`Food (${foodN} ${plural(foodN,'item','items')})`, fmt2(B.food)),
    rl(B.hourly ? `Bar (${B.hourly.tier.label.toLowerCase()}, ${B.hourly.hours} hr) & drinks` : 'Bar & drinks', fmt2(B.bar)),
    rl('Food & drink subtotal', fmt2(B.fb), 'tot'),
    B.shortfall > 0 ? rl('Short of $5,000 minimum, billed as rental', fmt2(B.shortfall), 'bad') : rl('$5,000 minimum', 'Met', 'good'),
    B.att + B.carve > 0 ? rl('Attendants & carvers', fmt2(B.att + B.carve)) : null,
    B.btFee > 0 ? rl(`Bartenders (${B.bartenders} × ${S.barHours} hr)`, fmt2(B.btFee)) : null,
    B.cashFee > 0 ? rl(`Cashiers (${S.cashiers} × ${S.barHours} hr)`, fmt2(B.cashFee)) : null,
    rl('Kullman Boardroom', fmt2(BOARDROOM)),
    rl('Salon 1 + holding suite', 'Waived', 'good'),
    rl(`Hotel AV & extras${unpricedHotel ? ` (${unpricedHotel} unpriced)` : ''}`, fmt2(B.hotelExpSum), unpricedHotel ? 'bad' : ''),
    rl('Subtotal', fmt2(B.sub), 'tot'),
    rl('Service charge 24%', fmt2(B.svc)),
    rl('Sales tax 12.5%', fmt2(B.tax)),
    rl('Hotel total', fmt2(B.hotelTotal), 'tot big'),
    rl('Deposit paid Oct 6', '−' + fmt2(DEPOSIT), 'good'),
    rl('Balance to the hotel', fmt2(B.balance), 'tot'),
    rl(`Outside the hotel (${B.outside.length} ${plural(B.outside.length,'line','lines')})`, fmt2(B.outsideSum)),
    rl('All-in', fmt2(B.all), 'tot big'),
    h('p',{class:'rc-note'}, 'Tax applies on top of the service charge, which matches how the hotel figured the $767.30 deposit. With nothing picked, this shows the contract minimum: $7,672.50. Final numbers come from the signed event order.')].filter(Boolean));
  const box = $('#exList');
  withFocus(box, () => box.replaceChildren(...buildExpenses(B)));
}
function buildExpenses(B){
  if (state.dbStatus === 'off') return [emptyCard('Budget lines live in Claude', 'Open this page in Claude while signed in to add costs.')];
  if (state.dbStatus === 'pending' || !state.loaded.expenses) return [emptyCard('Loading costs', 'Line items appear here in a moment.')];
  if (!state.expenses.length) return [emptyCard('No costs yet', 'Add balloons, the band, AV and anything else below.')];
  const sort = (a,b) => a.order - b.order || a.label.localeCompare(b.label);
  const priced = state.expenses.filter(e => e.amount > 0).length;
  const out = [h('p',{class:'hint', style:'margin:10px 0 0'}, h('b',null, `${priced} of ${state.expenses.length}`), ' lines have a number.')];
  const groups = [['Billed by the hotel', B.hotelExp, `${fmt0(B.hotelExpSum)} before service and tax`], ['Outside the hotel', B.outside, fmt0(B.outsideSum)]];
  for (const [title, list, total] of groups){
    if (!list.length) continue;
    out.push(h('div',{class:'ex-h'}, h('h3',null,title), h('span',null,total)));
    out.push(h('ul',{class:'ex-list'}, list.slice().sort(sort).map(exRow)));
  }
  return out;
}
function exRow(e){
  const ro = !canWrite(), armed = state.confirm === 'exp:' + e.id, stt = EXP_STATUS.find(s => s.key === e.status);
  const sub = [e.vendor, e.notes].filter(Boolean).join(' · ');
  return h('li',{class:'ex'},
    h('div',{class:'ex-main'}, h('div',{class:'ex-name'}, e.label), sub ? h('div',{class:'ex-sub'}, sub) : null, e.amount > 0 ? null : h('span',{class:'need'}, 'Needs a number')),
    h('select',{'aria-label':'Category for ' + e.label, 'data-fk':'xc-'+e.id, disabled:ro, onchange:ev => updateExp(e.id, {cat:ev.target.value})},
      EXP_CATS.map(c => h('option',{value:c.key, selected:c.key === e.cat}, c.label))),
    h('input',{type:'number', min:0, step:1, value:e.amount > 0 ? e.amount : '', placeholder:'$0', inputmode:'decimal', 'aria-label':'Amount for ' + e.label, 'data-fk':'xa-'+e.id, disabled:ro,
      onchange:ev => updateExp(e.id, {amount:Math.max(0, Math.round(num(ev.target.value,0)*100)/100)})}),
    h('select',{class:'pill ' + stt.pill, 'aria-label':'Status for ' + e.label, 'data-fk':'xs-'+e.id, disabled:ro, onchange:ev => updateExp(e.id, {status:ev.target.value})},
      EXP_STATUS.map(s => h('option',{value:s.key, selected:s.key === e.status}, s.label))),
    ro ? h('span') : h('button',{type:'button', class:'linkbtn red', 'data-fk':'xr-'+e.id, onclick:() => armed ? removeExp(e.id) : arm('exp:' + e.id)}, armed ? 'Confirm remove' : 'Remove'));
}

/* ---------- writes ---------- */
function writeFail(e){
  const code = e && e.code;
  if (code === 'invalid_argument' || code === 'not_granted'){
    state.readOnly = true; renderAll();
    toast("Can't save", 'This view is read-only. Ask Josh for Contributor or Editor access.');
  } else if (code === 'quota_exceeded') toast('Storage is full', 'Remove some entries, then try again.');
  else if (code === 'resource_exhausted') toast('Slow down a moment', 'Too many changes at once. Try again in a few seconds.');
  else toast("Couldn't save", 'Check your connection and try again.');
}
async function guarded(key, fn){
  if (!canWrite() || pending.has(key)) return false;
  pending.add(key);
  try { await fn(); return true; } catch(e){ writeFail(e); return false; } finally { pending.delete(key); }
}
async function toggleTask(id, el){
  const t = state.tasks.find(x => x.id === id); if (!t || !canWrite() || pending.has('t:'+id)) return;
  const done = !t.done;
  if (done){
    mine.add(id);
    const r = el && el.getBoundingClientRect();
    if (r) confetti.burst(r.left + r.width/2, r.top + r.height/2, 34, .8);
    toast(`+${t.votes} votes`, t.title);
  }
  const ok = await guarded('t:'+id, () => db.doc('tasks/' + id).update({done, doneBy:done ? meId() : null, doneAt:done ? nowISO() : null}));
  if (!ok) mine.delete(id);
}
function announceRemote(t){
  if (state.mode === 'local') return;
  const tpl = '{n} checked off';
  toast(tpl.replace('{n}', t.doneBy && state.names[t.doneBy] ? state.names[t.doneBy] : 'A teammate'), `${t.title} · +${t.votes} votes`);
  confetti.burst(innerWidth/2, 60, 26, .7);
}
async function removeTask(id){ state.confirm = null; await guarded('t:'+id, () => db.doc('tasks/' + id).delete()); }
async function addTask(ev){
  ev.preventDefault(); if (!canWrite()) return;
  const title = $('#tfTitle').value.trim().slice(0,120); if (!title){ $('#tfTitle').focus(); return; }
  const due = $('#tfDue').value;
  const doc = {title, detail:'', stream:$('#tfStream').value, due:isISO(due) ? due : null, votes:num($('#tfVotes').value,20),
    done:false, doneBy:null, doneAt:null, custom:true, order:1000 + state.tasks.length, addedBy:meId()};
  const ok = await guarded('newtask', () => db.collection('tasks').add(doc));
  if (ok){ $('#tfTitle').value = ''; $('#tfDue').value = ''; toast('Added to the board', title); $('#tfTitle').focus(); }
}
async function updateGuest(id, patch){ await guarded('g:'+id, () => db.doc('guests/' + id).update(patch)); }
async function saveGuest(id){
  const d = state.drafts[id]; if (!d) return;
  const name = (d.name || '').trim().slice(0,80); if (!name){ toast('Name needed', 'Add a name before saving.'); return; }
  const ok = await guarded('g:'+id, () => db.doc('guests/' + id).update({name, group:d.group, contact:(d.contact||'').trim().slice(0,120), notes:(d.notes||'').trim().slice(0,200)}));
  if (ok){ delete state.drafts[id]; state.editing = null; dirty.add('guests'); schedule(); }
}
async function removeGuest(id){
  state.confirm = null;
  const ok = await guarded('g:'+id, () => db.doc('guests/' + id).delete());
  if (ok){ delete state.drafts[id]; state.editing = null; dirty.add('guests'); schedule(); }
}
async function addGuest(ev){
  ev.preventDefault(); if (!canWrite()) return;
  const name = $('#gfName').value.trim().slice(0,80); if (!name){ $('#gfName').focus(); return; }
  if (state.guests.some(g => g.name.toLowerCase() === name.toLowerCase())){ toast('Already on the list', name); return; }
  const doc = {name, group:$('#gfGroup').value, status:$('#gfStatus').value, plusOnes:clamp(Math.round(num($('#gfPlus').value,0)),0,5),
    contact:$('#gfContact').value.trim().slice(0,120), notes:$('#gfNotes').value.trim().slice(0,200), addedBy:meId(), addedAt:nowISO()};
  const ok = await guarded('newguest', () => db.collection('guests').add(doc));
  if (ok){ ['#gfName','#gfContact','#gfNotes'].forEach(s => { $(s).value = ''; }); $('#gfPlus').value = '0'; toast('Added to the list', name); $('#gfName').focus(); }
}
async function pasteGuests(){
  if (!canWrite() || pending.has('paste')) return;
  const lines = $('#pasteText').value.split(/\r?\n/).map(s => s.trim()).filter(Boolean);
  if (!lines.length){ toast('Nothing to add', 'Paste at least one name.'); return; }
  pending.add('paste'); const btn = $('#pasteBtn'); btn.disabled = true;
  const seen = new Set(state.guests.map(g => g.name.toLowerCase()));
  let added = 0, skipped = 0, stopped = false; const left = [];
  for (const line of lines.slice(0,150)){
    const i = line.indexOf(','); const name = (i >= 0 ? line.slice(0,i) : line).trim().slice(0,80);
    const grp = matchGroup(i >= 0 ? line.slice(i+1) : '') || $('#gfGroup').value;
    if (!name || seen.has(name.toLowerCase())){ skipped++; continue; }
    if (stopped){ left.push(line); continue; }
    try {
      await db.collection('guests').add({name, group:grp, status:$('#gfStatus').value, plusOnes:0, contact:'', notes:'', addedBy:meId(), addedAt:nowISO()});
      seen.add(name.toLowerCase()); added++;
    } catch(e){ stopped = true; left.push(line); if (e && e.code !== 'resource_exhausted') writeFail(e); }
  }
  pending.delete('paste'); btn.disabled = !canWrite();
  $('#pasteText').value = left.concat(lines.slice(150)).join('\n');
  toast(`Added ${added} ${plural(added,'guest','guests')}`, [skipped ? `${skipped} already on the list` : '', left.length ? 'The rest are still in the box; try again in a minute.' : ''].filter(Boolean).join(' · '));
  if (added >= 10) confetti.burst(innerWidth/2, innerHeight*.4, 50, 1);
}
async function togglePick(id){
  const it = ITEMS[id]; if (!it) return;
  if (state.picks[id]) await guarded('p:'+id, () => db.doc('picks/' + id).delete());
  else {
    const ok = await guarded('p:'+id, () => db.doc('picks/' + id).set({qty:defaultQty(it, state.settings.headcount), follow:it.unit === 'pp', by:meId(), at:nowISO()}));
    if (ok) toast('Added to the menu', it.name);
  }
}
async function setPickQty(id, val){
  const it = ITEMS[id]; if (!it || !state.picks[id]) return;
  let q = Math.round(num(val, 0));
  if (q <= 0){ await guarded('p:'+id, () => db.doc('picks/' + id).delete()); return; }
  if (it.unit === 'pc50'){ const r = Math.max(50, Math.ceil(q/50)*50); if (r !== q) toast('Rounded to 50s', `${it.name} is sold by 50 pieces: ${r}.`); q = r; }
  await guarded('p:'+id, () => db.doc('picks/' + id).update({qty:q, follow:false}));
}
async function followPick(id){ await guarded('p:'+id, () => db.doc('picks/' + id).update({follow:true})); }
async function pickHourly(id){
  if (!canWrite() || pending.has('hourly')) return;
  const existing = Object.keys(state.picks).filter(k => k.startsWith('hourly-'));
  pending.add('hourly');
  try {
    for (const k of existing) await db.doc('picks/' + k).delete();
    if (!existing.includes(id)) await db.doc('picks/' + id).set({qty:0, follow:true, by:meId(), at:nowISO()});
  } catch(e){ writeFail(e); } finally { pending.delete('hourly'); }
}
function saveSettings(patch){
  if (!canWrite()) return;
  state.settings = cleanSettings(Object.assign({}, state.settings, patch));
  settingsDirty = true; changed('menu','budget');
  clearTimeout(settingsTimer);
  settingsTimer = setTimeout(() => {
    const body = Object.assign({}, state.settings);
    settingsChain = settingsChain.then(() => db.doc('settings/budget').set(body)).catch(writeFail).then(() => { settingsDirty = false; });
  }, 450);
}
async function updateExp(id, patch){ await guarded('x:'+id, () => db.doc('expenses/' + id).update(patch)); }
async function removeExp(id){ state.confirm = null; await guarded('x:'+id, () => db.doc('expenses/' + id).delete()); }
async function addExp(ev){
  ev.preventDefault(); if (!canWrite()) return;
  const label = $('#efLabel').value.trim().slice(0,80); if (!label){ $('#efLabel').focus(); return; }
  const doc = {label, cat:$('#efCat').value, amount:Math.max(0, Math.round(num($('#efAmt').value,0)*100)/100), status:$('#efStatus').value,
    vendor:$('#efVendor').value.trim().slice(0,80), notes:$('#efNotes').value.trim().slice(0,200), order:1000 + state.expenses.length, addedBy:meId(), addedAt:nowISO()};
  const ok = await guarded('newexp', () => db.collection('expenses').add(doc));
  if (ok){ ['#efLabel','#efAmt','#efVendor','#efNotes'].forEach(s => { $(s).value = ''; }); toast('Added to the budget', label); $('#efLabel').focus(); }
}

/* ---------- static UI ---------- */
function opt(list, sel){ return list.map(x => h('option',{value:x.key, selected:x.key === sel}, x.label)); }
function fillStatic(){
  $('#tfStream').replaceChildren(...opt(STREAMS,'night'));
  $('#gfGroup').replaceChildren(...opt(GROUPS,'friends'));
  $('#gfStatus').replaceChildren(...opt(STATUSES,'todo'));
  $('#gGroupF').replaceChildren(h('option',{value:''},'All groups'), ...opt(GROUPS));
  $('#efCat').replaceChildren(...opt(EXP_CATS,'decor'));
  $('#efStatus').replaceChildren(...opt(EXP_STATUS,'estimate'));
  $('#mJump').replaceChildren(...MENU.map(s => h('button',{type:'button', class:'chip', onclick:() => {
    const el = document.getElementById('m-' + s.key);
    if (el) el.scrollIntoView({behavior:reduceMotion() ? 'auto' : 'smooth', block:'start'});
    else toast('Hidden by your filters', 'Clear the search or "Picked only" to see this section.');
  }}, s.title.replace("Hors d'oeuvres · ","Hors d'oeuvres, ").replace('Bar · ','Bar, '))));
  const box = $('#contacts');
  CONTACTS.forEach(c => box.append(h('div',{class:'contact'}, h('span',{class:'who'}, c.who), h('span',{class:'role'}, c.role),
    c.vals.map(v => { const span = h('span',null,v); return h('div',{class:'cv'}, span, h('button',{type:'button', class:'linkbtn', onclick:() => copyText(v, v, span)}, 'Copy')); }))));
}
function applyTab(){
  TABS.forEach(t => { const b = $('#tab-' + t), p = $('#p-' + t), on = t === state.tab; b.setAttribute('aria-selected', on ? 'true' : 'false'); b.tabIndex = on ? 0 : -1; p.hidden = !on; });
}
function setTab(t, focus){
  if (!TABS.includes(t)) return;
  state.tab = t; applyTab(); savePrefs(); if (focus) $('#tab-' + t).focus(); schedule();
}
function bindStatic(){
  $$('.tabs button').forEach(b => {
    b.addEventListener('click', () => setTab(b.dataset.tab));
    b.addEventListener('keydown', e => {
      const i = TABS.indexOf(b.dataset.tab);
      if (e.key === 'ArrowRight'){ e.preventDefault(); setTab(TABS[(i+1) % TABS.length], true); }
      if (e.key === 'ArrowLeft'){ e.preventDefault(); setTab(TABS[(i-1+TABS.length) % TABS.length], true); }
    });
  });
  $$('[data-goto]').forEach(b => b.addEventListener('click', () => { setTab(b.dataset.goto); $('.tabs').scrollIntoView({behavior:reduceMotion() ? 'auto' : 'smooth'}); }));
  $$('.seg button').forEach(b => b.addEventListener('click', () => { state.view = b.dataset.view; savePrefs(); dirty.add('board'); schedule(); }));
  $('#hideDone').addEventListener('change', e => { state.hideDone = e.target.checked; savePrefs(); dirty.add('board'); schedule(); });
  $('#addTaskBtn').addEventListener('click', () => { const f = $('#taskForm'); f.hidden = !f.hidden; $('#addTaskBtn').setAttribute('aria-expanded', String(!f.hidden)); if (!f.hidden) $('#tfTitle').focus(); });
  $('#tfCancel').addEventListener('click', () => { $('#taskForm').hidden = true; $('#addTaskBtn').setAttribute('aria-expanded','false'); });
  $('#taskForm').addEventListener('submit', addTask);
  $('#guestForm').addEventListener('submit', addGuest);
  $('#pasteBtn').addEventListener('click', pasteGuests);
  $('#gSearch').addEventListener('input', () => { dirty.add('guests'); schedule(); });
  $('#gGroupF').addEventListener('change', () => { dirty.add('guests'); schedule(); });
  $('#guestList').addEventListener('focusout', () => setTimeout(() => { if (dirty.has('guests')) schedule(); }, 0));
  $('#copyCount').addEventListener('click', () => copyText(headcountText(), 'Headcount summary'));
  $('#copyList').addEventListener('click', () => copyText(guestListText(), 'Guest list (pastes into a spreadsheet)'));
  $('#mSearch').addEventListener('input', e => { state.mSearch = e.target.value; dirty.add('menu'); schedule(); });
  $('#mPicked').addEventListener('change', e => { state.mPicked = e.target.checked; dirty.add('menu'); schedule(); });
  $('#copyOrder').addEventListener('click', () => copyText(orderText(), 'Menu order'));
  ['#hcMenu','#hcBudget'].forEach(s => $(s).addEventListener('change', e => { const v = Math.round(num(e.target.value,0)); if (v >= 1) saveSettings({headcount:v}); }));
  $('#capInput').addEventListener('change', e => saveSettings({cap:num(e.target.value,0)}));
  ['#peakMenu','#peakBudget'].forEach(s => $(s).addEventListener('change', e => saveSettings({peak:e.target.value === '' ? null : Math.round(num(e.target.value,0)) || null})));
  $('#targetInput').addEventListener('change', e => saveSettings({target:num(e.target.value,0)}));
  $('#useGuests').addEventListener('click', () => {
    const st = stats(), n = st.confirmed + st.maybe;
    if (!n){ toast('No RSVPs yet', 'Mark guests as Coming or Maybe on the Guest list tab.'); return; }
    saveSettings({headcount:n}); toast('Planning for ' + nf.format(n), 'Coming plus maybe, including +1s.');
  });
  $('#exForm').addEventListener('submit', addExp);
  if ($('#exportBtn')){
    $('#exportBtn').addEventListener('click', exportData);
    $('#importBtn').addEventListener('click', () => $('#importFile').click());
    $('#importFile').addEventListener('change', e => importData(e.target.files && e.target.files[0]));
    $('#resetBtn').addEventListener('click', resetData);
  }
}
const RENDER = {board:renderBoard, guests:renderGuests, menu:renderMenu, budget:renderBudget};

/* ---------- live data ---------- */
function dbErr(e){
  if (e && e.code === 'revoked'){ state.dbStatus = 'off'; renderAll(); return; }
  toast('Live updates paused', 'Reload the page to reconnect.');
}
function subscribe(){
  db.collection('tasks').onSnapshot(snap => {
    const prev = new Map(state.tasks.map(t => [t.id, t])), first = !state.loaded.tasks;
    state.tasks = snap.docs.map(cleanTask); state.loaded.tasks = true;
    if (!first) for (const t of state.tasks){ const p = prev.get(t.id); if (p && !p.done && t.done){ if (mine.has(t.id)) mine.delete(t.id); else announceRemote(t); } }
    changed('board');
  }, dbErr);
  db.collection('guests').onSnapshot(snap => { state.guests = snap.docs.map(cleanGuest); state.loaded.guests = true; changed('guests','budget'); }, dbErr);
  db.collection('picks').onSnapshot(snap => { const o = {}; snap.docs.forEach(d => { o[d.id] = cleanPick(d); }); state.picks = o; state.loaded.picks = true; changed('menu','budget'); }, dbErr);
  db.collection('expenses').onSnapshot(snap => { state.expenses = snap.docs.map(cleanExp); state.loaded.expenses = true; changed('budget'); }, dbErr);
  db.doc('settings/budget').onSnapshot(snap => {
    if (!settingsDirty) state.settings = cleanSettings(snap.exists ? snap.data() : {});
    state.loaded.settings = true; changed('menu','budget');
  }, dbErr);
}
async function connect(){
  // Inside Claude: use the artifact's shared database. Anywhere else (GitHub Pages, a local file): this browser.
  const c = window.claude;
  if (c && typeof c.use === 'function'){
    let d = null, u = null;
    try { [d, u] = await Promise.all([c.use('db'), c.use('user')]); } catch(e){}
    if (d){
      db = d; user = u; state.mode = 'shared'; state.dbStatus = 'on';
      if (user){
        try { state.me = await user.me(); } catch(e){}
        try { if (await user.can('data.write') === false) state.readOnly = true; } catch(e){}
      }
      subscribe(); renderAll(); renderModeUI(); return;
    }
  }
  if (typeof LocalStore === 'undefined'){ state.dbStatus = 'off'; renderAll(); return; }
  db = LocalStore.open(); state.mode = 'local'; state.dbStatus = 'on';
  subscribe(); renderAll(); renderModeUI();
}

/* ---------- browser-only mode: backup, restore, reset ---------- */
function renderModeUI(){
  const local = state.mode === 'local';
  const tools = $('#dataTools'); if (tools) tools.hidden = !local;
  const hint = $('#shareHint'); if (hint && local) hint.textContent = 'Saved in this browser. Export a backup at the bottom of the page to move it or share it.';
}
function exportData(){
  try {
    const blob = new Blob([JSON.stringify(LocalStore.dump(), null, 2)], {type:'application/json'});
    const a = h('a', {href:URL.createObjectURL(blob), download:`hm26-watch-party-${todayISO()}.json`});
    document.body.append(a); a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1500);
    toast('Backup saved', a.download);
  } catch(e){ toast("Couldn't export", 'This browser blocked the download.'); }
}
function importData(file){
  if (!file) return;
  const r = new FileReader();
  r.onload = () => {
    try {
      const obj = JSON.parse(String(r.result));
      state.quietUntil = Date.now() + 1500; state.editing = null; state.drafts = {};
      LocalStore.replace(obj);
      const n = o => (o && typeof o === 'object') ? Object.keys(o).length : 0;
      toast('Backup imported', `${n(obj.tasks)} to-dos · ${n(obj.guests)} guests · ${n(obj.expenses)} costs`);
    } catch(e){ toast("Couldn't import", (e && e.message) || 'That file is not a watch party backup.'); }
    $('#importFile').value = '';
  };
  r.onerror = () => toast("Couldn't import", 'The file could not be read.');
  r.readAsText(file);
}
let resetArmed = 0;
function resetData(){
  const btn = $('#resetBtn');
  if (!resetArmed){
    btn.textContent = 'Click again to erase this browser\'s data';
    resetArmed = setTimeout(() => { resetArmed = 0; btn.textContent = 'Reset to starting data'; }, 4000);
    return;
  }
  clearTimeout(resetArmed); resetArmed = 0; btn.textContent = 'Reset to starting data';
  state.quietUntil = Date.now() + 1500; state.editing = null; state.drafts = {};
  LocalStore.reset(); toast('Reset', 'Back to the starting to-dos, guests and costs.');
}
function boot(){
  loadPrefs();
  const hash = (location.hash || '').slice(1); if (TABS.includes(hash)) state.tab = hash;
  fillStatic(); bindStatic(); applyTab(); renderSteps(); renderAll(); tickCountdown();
  setInterval(tickCountdown, 30000);
  connect();
}
boot();

})();
