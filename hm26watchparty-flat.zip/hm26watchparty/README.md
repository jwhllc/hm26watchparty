# HM26 Watch Party

A planning hub for Hillar Moore's election night watch party: Tuesday, November 3, 2026, 5 PM to midnight, Salon 1 at the Renaissance Baton Rouge (7000 Bluebonnet Blvd.).

It's a single static page with no build step and no server. Everything you change is saved in your own browser.

## What's in it

| Tab | What it does |
|---|---|
| Race board | Hotel to-dos with due dates. Checking one off earns votes, fills the workstream bars, and moves "precincts reporting." There are 12 badges to unlock. |
| Guest list | Add guests one at a time or paste a list. Track RSVPs and +1s, and copy a headcount for the hotel. |
| Menu | The evening sections of the Renaissance 2026 menu (hors d'oeuvres, stations, carving, desserts, dinner buffets, bar, wine), with quantities and attendant/carver fees. |
| Budget | An estimate of the hotel banquet check (24% service, 12.5% tax, $5,000 minimum, $767.30 deposit) plus outside costs, tracked against a $10K target and a $15K ceiling. |
| Venue & contract | Booking details, rooms, money terms, cancellation terms, house rules. |
| Flyer & contacts | The flyer, contacts with copy buttons, and the paper trail from the email thread. |

## How data is saved

Data lives in each browser's `localStorage`. That means:

- **Nothing is shared automatically.** Your check-offs don't show up for Hayden, and hers don't show up for you.
- **To share or move data,** use **Export backup** at the bottom of the page. That saves a `.json` file. The other person opens the site and uses **Import backup**. Importing replaces what's in their browser.
- **Clearing browser data or using a private window loses changes.** Export a backup now and then.
- **Reset to starting data** puts back the to-dos, core team, and cost lines from `seed.js`.

`.gitignore` excludes exported backups (`hm26-watch-party-*.json`), because they can contain guest names and contacts.

## Put it on GitHub Pages

1. Create a new repository, for example `hm26-watch-party`.
2. Upload every file in this folder to the top level of the repo. `.nojekyll` and `.gitignore` are optional; turn on hidden files on your computer if you want them.
3. In the repository, go to **Settings → Pages**. Under **Build and deployment**, choose **Deploy from a branch**, pick `main` and `/ (root)`, then click **Save**.
4. After a minute, the site is live at `https://<your-username>.github.io/hm26-watch-party/`.

To try it before publishing, open `index.html` in a browser. Or run `python3 -m http.server` in this folder and visit `http://localhost:8000`.

**Visibility:** A GitHub Pages site is public to anyone who has the link, even if the repository is private (unless you're on GitHub Enterprise). Everything in these files can be seen by anyone with the link. That includes contact emails and phone numbers, the room confirmation number, contract figures, and the notes inside the to-dos. The `noindex` tag asks search engines not to list the page, but it doesn't hide it. Guest list entries and budget numbers you type in stay in your browser and are not published.

## Editing

| To change | Edit |
|---|---|
| Starting to-dos, team list, cost lines, target/ceiling/headcount | `seed.js` (only affects browsers opening the site for the first time, or after a reset) |
| Menu items and prices, deadlines, contacts, guest groups, cost categories | `data.js` |
| Venue facts, house rules, paper trail, flyer note | `index.html` |
| Budget math, badges, game behavior | `app.js` (`budget()`, `BADGES`) |
| Colors, type, layout | `style.css` (color tokens are at the top, with dark mode) |

Budget math: hotel subtotal = food and drink (or the $5,000 minimum, whichever is higher) + attendant, carver, bartender and cashier fees + the $500 Kullman Boardroom + hotel AV and extras. Then add a 24% service charge, and 12.5% tax on top of both. That's how the hotel calculated the $767.30 deposit. Outside costs count at face value.

## Files

All files sit at the top level of the repo (no folders), next to `index.html`:

```
index.html        page markup
style.css         styles (light and dark)
data.js           reference data and the hotel menu
seed.js           starting data for a new browser
store.js          browser storage, backup export and import
app.js            the app
logo.png, flyer.jpg, icon.png, favicon.png
```

The app also runs unchanged as a Claude artifact. If `window.claude` is present, it uses Claude's shared database instead of the browser.

Sources: Renaissance Baton Rouge group sales agreement (ref M-WQ83ATW), the Nov 3 event email thread (Aug 7 to Oct 12, 2026), and the Renaissance Meeting + Event Menus, 2026 edition.
